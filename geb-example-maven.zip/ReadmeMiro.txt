1. https://www.softwaretestingmaterial.com/failed-to-launch-ie-driver-using-selenium/
2. View->zoom->100% (ctrl+0)
3. mvn clean test (download drivers in background)


//mvn surefire:test -Dtest=secondtestngTest??
mvn clean test -Dtest=secondtestngTest
//bez przecinka
mvn clean test -Dtest=flightsStrapTestngTest,loginTest

taskkill /F /IM chromedriver-windows-32bit.exe /T

mvn clean test -Dtest=GebishOrgSpec

