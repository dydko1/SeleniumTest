package spec1

import geb.spock.GebReportingSpec
import geb.transform.implicitassertions.ByNameImplicitlyAssertedMethodCallMatcher
import modules1.DemoGuruMenu
import org.openqa.selenium.By
import pages1.DemoGuruRegisterPage
import spock.lang.Stepwise

@Stepwise
class DemoGuruMiroSpec extends GebReportingSpec {

    def "Go to Main Page"() {
        given: "Go to demo.guru"
        to DemoGuruRegisterPage
        when:
        //signON.click()
        //tab2.click()
        //menue.flights.click()
        menue.register.click()
        then:
        //form.click()
        firstName.value("Mirek")
        //radios.click()

        //country.click()
        //country.value("ANGOLA")
        //DemoGuruRegisterPage.
          //      country.selected="ANGOLA"

        country.value("POLAND")
        //dropdownSelectedText == "ANGOLA"
        sleep(5000)
    }
}

/*
        sleep(2000)
        menue.flights.click()
        sleep(2000)
        menue.hotels.click()
        sleep(2000)
        menue.carRentals.click()
        sleep(2000)
        menue.cruises.click()
        sleep(2000)
        menue.destinations.click()
        sleep(2000)
        menue.vacations.click()
        sleep(2000)

        //sleep(1000)
        menue.signON.click()
        sleep(2000)
        menue.register.click()
        sleep(2000)
        menue.support.click()
        sleep(2000)
        menue.contact.click()
        sleep(2000)
* */